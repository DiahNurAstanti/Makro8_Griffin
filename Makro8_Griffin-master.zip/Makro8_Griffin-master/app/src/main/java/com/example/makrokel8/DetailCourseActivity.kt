package com.example.makrokel8

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton

class DetailCourseActivity : AppCompatActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_course)

        val btn_back1: ImageButton = findViewById<ImageButton>(R.id.back1)
        val btn_reg: ImageButton = findViewById<ImageButton>(R.id.btn_reg)

        btn_reg.setOnClickListener {
            val intent = Intent(this, JadwalKelasActivity::class.java)
            startActivity(intent)
        }

        // Aksi saat tombol 2 diklik
        btn_back1.setOnClickListener {
            val intent = Intent(this, CourseActivity::class.java)
            startActivity(intent)
        }

    }
}

